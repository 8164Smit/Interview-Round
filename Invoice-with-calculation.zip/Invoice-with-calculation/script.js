document.addEventListener('DOMContentLoaded', () => {
    const invoiceItemsDiv = document.getElementById('invoiceItems');
    const addItemBtn = document.getElementById('addItemBtn');
    const totalAmountSpan = document.getElementById('totalAmount');

    let itemCounter = 0;

    function createItemRow() {
        itemCounter++;
        const row = document.createElement('div');
        row.classList.add('invoice-item');
        row.innerHTML = `
            <input type="text" placeholder="Item Name" class="item-name">
            <input type="number" placeholder="Quantity" class="item-quantity" value="1" min="1">
            <input type="number" placeholder="Price per unit" class="item-price" value="0.00" min="0" step="0.01">
            <span class="total-col">$<span class="item-total">0.00</span></span>
            <button class="removeItemBtn">Remove</button>
        `;

        invoiceItemsDiv.appendChild(row);

        const quantityInput = row.querySelector('.item-quantity');
        const priceInput = row.querySelector('.item-price');
        const itemTotalSpan = row.querySelector('.item-total');
        const removeItemBtn = row.querySelector('.removeItemBtn');

        function updateItemTotal() {
            const quantity = parseFloat(quantityInput.value) || 0;
            const price = parseFloat(priceInput.value) || 0;
            const itemTotal = quantity * price;
            itemTotalSpan.textContent = itemTotal.toFixed(2);
            updateGrandTotal();
        }

        quantityInput.addEventListener('input', updateItemTotal);
        priceInput.addEventListener('input', updateItemTotal);
        removeItemBtn.addEventListener('click', () => {
            row.remove();
            updateGrandTotal();
        });

        updateItemTotal();
    }

    function updateGrandTotal() {
        let grandTotal = 0;
        document.querySelectorAll('.item-total').forEach(itemTotalSpan => {
            grandTotal += parseFloat(itemTotalSpan.textContent);
        });
        totalAmountSpan.textContent = grandTotal.toFixed(2);
    }

    addItemBtn.addEventListener('click', createItemRow);
    createItemRow();
});